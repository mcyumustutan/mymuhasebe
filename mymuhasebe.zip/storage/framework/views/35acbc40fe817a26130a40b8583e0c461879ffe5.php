<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Giderler </div>

                <div class="card-body">

                <div class="jumbotron">
                    Genel Toplam : <?php echo e($toplam); ?>

                </div>

                <table class="table table-hover">
                <thead>
                <tr>
                    <th>Tarih</th>
                    <th>Ad</th>
                    <th>Resmi Ad</th>
                    <th>Hesap</th>
                    <th>Tutar</th>
                    <th>Açıklama</th>
                    <th>İşlem</th>
                </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $giderler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $giderler): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($giderler['tarih']); ?></td>
                        <td><?php echo e($giderler['ad']); ?></td>
                        <td><?php echo e($giderler['resmi_ad']); ?></td>
                        <td><?php echo e($giderler['hesap']['hesap_adi']); ?></td>
                        <td><?php echo e($giderler['tutar']); ?></td>
                        <td><?php echo e($giderler['aciklama']); ?></td>
                        <td>Sil | Güncelle</td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mymuhasebe/resources/views/Giderler/liste.blade.php ENDPATH**/ ?>