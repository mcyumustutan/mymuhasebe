<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hesaplar extends Model
{
    protected $table = 'hesaplar';
}
